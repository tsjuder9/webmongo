export namespace llaves{
    export const claveJWT="M1s10nT1c2022";
    export const urlServicioNotificaciones='http://localhost:5000/';
}